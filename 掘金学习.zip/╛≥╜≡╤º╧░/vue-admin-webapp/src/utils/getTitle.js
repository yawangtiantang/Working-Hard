const title = 'vue-admin-webapp'
const getTitle = function(til) {
  let allTitle = til + '-' + title
  return allTitle
}
export default getTitle
