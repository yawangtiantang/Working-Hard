<template>
  <div class="notifications"></div>
</template>

<script>
export default {}
</script>
<style lang="scss" scoped></style>
