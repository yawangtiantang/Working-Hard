<template>
  <div class="className">nav1</div>
</template>

<script>
export default {
  name: 'Nav1'
}
</script>
<style lang="scss" scoped></style>
