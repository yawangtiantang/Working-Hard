<template>
  <div class="className">nav2-2-2</div>
</template>

<script>
export default {
  name: ''
}
</script>
<style lang="scss" scoped></style>
