<template>
  <div class="className">
    <p>nav2-2</p>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: ''
}
</script>
<style lang="scss" scoped></style>
