<template>
  <div class="className">nav2-2-1</div>
</template>

<script>
export default {
  name: ''
}
</script>
<style lang="scss" scoped></style>
