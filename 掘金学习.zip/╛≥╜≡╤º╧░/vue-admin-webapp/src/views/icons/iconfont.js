export const alIcons = [
  'el-icon-weixin',
  'el-icon-github',
  'el-icon-twitter',
  'el-icon-table',
  'el-icon-weibo',
  'el-icon-dashang',
  'el-icon-guojihua',
  'el-icon-huangguan',
  'el-icon-lunbo',
  'el-icon-excel'
]
